package com.assignment.inventoryapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.ArrayList;

public class DataLayout extends RecyclerView.Adapter<DataLayout.MyViewHolder>{
    // calls our Context which we have to import to use
    private Context context;
    // our array list where we will be keeping our data in it to be able to show it
    private ArrayList itemName_id, itemAmount_id, itemId;


    // Our Datalayout constructor
    public DataLayout(Context context, ArrayList itemId, ArrayList itemName_id, ArrayList itemAmount_id) {
        this.context = context;
        this.itemId = itemId;
        this.itemName_id = itemName_id;
        this.itemAmount_id = itemAmount_id;
    }


    // our view holder where we will be using the xml file and push the data into that
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.activity_data_layout, parent, false);
        return new MyViewHolder(v);
    }

    // our holder class which gets the position on where the information is stored
    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.itemId.setText(String.valueOf(itemId.get(position)));
        holder.itemName_id.setText(String.valueOf(itemName_id.get(position)));
        holder.itemAmount_id.setText(String.valueOf(itemAmount_id.get(position)));
    }

    // gets the size of itemId
    @Override
    public int getItemCount() {
        return itemId.size();
    }


    public class MyViewHolder extends RecyclerView.ViewHolder {

        // Down below here is where we call our items so that we can get
        // them connected to the xml file and be able to use them
        TextView itemId, itemName_id, itemAmount_id;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            // connecting our items to our xml files so that we can use them
            itemId = itemView.findViewById(R.id.itemId);
            itemName_id = itemView.findViewById(R.id.itemDescription);
            itemAmount_id = itemView.findViewById(R.id.itemAmount);

            // allows us to click on the edit item image button to go to the edit page when clicked
            itemView.findViewById(R.id.editItemImageButton).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent myInt = new Intent(v.getContext(),EditItem.class);
                    v.getContext().startActivity(myInt);
                }
            });

            // allows us to click on the trash can icon to go to the delete page when clicked
            itemView.findViewById(R.id.deleteItemImageButton).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent myInt = new Intent(v.getContext(),DeleteItem.class);
                    v.getContext().startActivity(myInt);
                }
            });
        }

    }
}
