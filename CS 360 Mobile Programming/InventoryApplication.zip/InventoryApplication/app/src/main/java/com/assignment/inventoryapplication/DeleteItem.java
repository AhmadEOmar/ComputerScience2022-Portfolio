package com.assignment.inventoryapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class DeleteItem extends AppCompatActivity {

    // Down below here is where we call our items so that we can get
    // them connected to the xml file and be able to use them
    EditText itemIdDelete;
    Button backToInventory, deleteItem;

    // Calling our ItemDBHelper class which has the logic for our delete process
    ItemDBHelper myDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_item);

        // connecting our items to our xml files so that we can use them
        itemIdDelete = (EditText) findViewById(R.id.deleteItemId);

        // connecting our items to our xml files so that we can use them
        backToInventory = (Button) findViewById(R.id.cancelDeleteButton);
        deleteItem = (Button) findViewById(R.id.deleteItemButton);

        // Calling in our ItemDBHelper class which will
        // allow us to use the functions in that class
        // to delete items
        myDB = new ItemDBHelper(this);


        // our delete function will check for the Id of the item
        deleteItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String itemDeleteInventoryItem = itemIdDelete.getText().toString();

                // if our id matches it will call our delete function to delete our item for
                // the database
                Boolean deleteData = myDB.deleteInventoryData(itemDeleteInventoryItem);
                if(deleteData == true)
                {
                    // lets the user know the item has been deleted and takes them back to the
                    // inventory page
                    Toast.makeText(DeleteItem.this, "Item Deleted", Toast.LENGTH_SHORT).show();
                    Intent myInt = new Intent(DeleteItem.this, InventoryPage.class);
                    startActivity(myInt);
                }
                else
                {
                    // if the id is wrong it will let the user know that
                    // the item was not able to be deleted
                    Toast.makeText(DeleteItem.this, "Item Was Not Able To Update", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Our cancel button that will take the user back to the inventory page if they didn't
        // mean to get into the delete page
        backToInventory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myInt = new Intent(DeleteItem.this, InventoryPage.class);
                startActivity(myInt);
            }
        });


    }
}