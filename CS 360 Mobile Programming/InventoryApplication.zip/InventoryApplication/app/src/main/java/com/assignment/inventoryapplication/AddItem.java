package com.assignment.inventoryapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddItem extends AppCompatActivity {

    // Down below here is where we call our items so that we can get
    // them connected to the xml file and be able to use them
    EditText itemId, itemDescription, itemAmount;
    Button backToInventoryPage, addItem;

    // Call our ItemDBHelper so that we can use the function within it to add items to our database
    ItemDBHelper myInventoryDB;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        // connecting our items to our xml files so that we can use them
        itemId = (EditText) findViewById(R.id.enterItemId);
        itemDescription = (EditText) findViewById(R.id.enterItemDescription);
        itemAmount = (EditText) findViewById(R.id.enterItemAmount);

        addItem = (Button) findViewById(R.id.addInventoryButton);
        backToInventoryPage = (Button) findViewById(R.id.cancelButton);

        // calling our ItemDBHelper to use it's functions inside of the add button page
        myInventoryDB = new ItemDBHelper(this);

        // Adds items by getting the text used in our edit text items
        addItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String idText = itemId.getText().toString();
                String itemDescrip = itemDescription.getText().toString();
                String itemNumber = itemAmount.getText().toString();

                // checks if any of the fields are empty and if they are prompt the user to enter
                // all the information needed
                if(idText.equals("") || itemDescrip.equals("") || itemNumber.equals(""))
                {
                    Toast.makeText(AddItem.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                }
                // we call our ItemDBHelper function where we are able to insert the data into the
                // database and if works or not the user will get a prompt telling them if it worked
                // or not
                else
                {
                    Boolean checkInsertData = myInventoryDB.insertInventoryData(idText ,itemDescrip, itemNumber);

                    if(checkInsertData == true)
                    {
                        Toast.makeText(AddItem.this, "New Entry Inserted", Toast.LENGTH_SHORT).show();
                        Intent myInt = new Intent(AddItem.this, InventoryPage.class);
                        startActivity(myInt);
                    }
                    else
                    {
                        Toast.makeText(AddItem.this, "New Entry Not Inserted", Toast.LENGTH_SHORT).show();
                    }
                }


            }
        });

        // this is our cancel button in which if clicked it will take the user back to the
        // inventory page
        backToInventoryPage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myInt = new Intent(AddItem.this, InventoryPage.class);
                startActivity(myInt);
            }
        });

    }
}