package com.assignment.inventoryapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class DBHelper extends SQLiteOpenHelper {

    // tells our program to make a SQLite database called Login.db
    public DBHelper(Context context) {
        super(context, "Login.db", null, 1);
    }

    // creates the database with the username as the primary key and the password. They are both
    // stored as TEXT
    @Override
    public void onCreate(SQLiteDatabase myDB) {
        myDB.execSQL("create Table users(username Text primary key, password Text)");
    }

    // On upgrade it will drop the table if the users exist
    @Override
    public void onUpgrade(SQLiteDatabase myDB, int oldVersion, int newVersion) {

        myDB.execSQL("drop Table if exists users");
    }

    // our boolean class for inserting data into our database which will take
    // username, and password
    public Boolean insertData(String username, String password)
    {
        // lets us to write into the database and update the content for each field
        SQLiteDatabase myDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("username", username);
        contentValues.put("password", password);
        long result = myDB.insert("users", null, contentValues);

        if (result == -1)
        {
            return false;
        }
        else
        {
            return true;
        }
    }


    // our boolean class for checking the username data we will use this to ensure that our users
    // have unique usernames
    public Boolean checkUsername(String username)
    {
        SQLiteDatabase myDB = this.getWritableDatabase();
        Cursor cursor = myDB.rawQuery("select * from users where username = ?" , new String[] {username});

        if (cursor.getCount() > 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    // our boolean class for checking the username and password data
    // we will use this to ensure that our users are inputting the correct username and password
    // before they will be able to log into the application
    public Boolean checkUsernamePassword(String username, String password)
    {
        SQLiteDatabase myDB = this.getWritableDatabase();
        Cursor cursor = myDB.rawQuery("select * from users where username = ? and password = ?" , new String[] {username, password});

        if (cursor.getCount()>0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}
