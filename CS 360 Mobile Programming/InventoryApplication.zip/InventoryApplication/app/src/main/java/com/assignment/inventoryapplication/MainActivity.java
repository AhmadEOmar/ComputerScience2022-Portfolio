package com.assignment.inventoryapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

    // This page is our login screen which I accidentally created called main activity
    // instead of login page.
public class MainActivity extends AppCompatActivity {


    // Down below here is where we call our items so that we can get
    // them connected to the xml file and be able to use them
    EditText username, password;
    Button signIn, createAccount;

    // Calling our DBHelper class which has the logic for our login process
    DBHelper myDB;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // connecting our items to our xml files so that we can use them
        username = (EditText) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);

        // connecting our items to our xml files so that we can use them
        signIn = (Button) findViewById(R.id.loginButton);
        createAccount = (Button) findViewById(R.id.createAccountButton);

        // Calling in our DBHelper class which will allow us to use the functions in that class
        myDB = new DBHelper(this);



        // Our sign in button when clicked gets the information in the username and password field
        signIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = username.getText().toString();
                String pass = password.getText().toString();

                // if the username or password field are empty they will get a message telling them
                // to enter that information
                if(user.equals("") || pass.equals(""))
                {
                    Toast.makeText(MainActivity.this, "Please enter your information.", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    // checks with our database to see if the username and password are there
                    // if they are they will be taken to the inventory page and can use the app
                    Boolean checkInfo = myDB.checkUsernamePassword(user, pass);
                    if(checkInfo == true)
                    {
                        Intent myInt = new Intent(MainActivity.this, InventoryPage.class);
                        startActivity(myInt);
                    }
                    // if one of the fields is wrong they will be given a message that the
                    // information was invalid and to re-type it
                    else
                    {
                        Toast.makeText(MainActivity.this, "Invalid Creds", Toast.LENGTH_SHORT).show();
                    }
                }

            }
        });


        // if they click the create account it will take them to the create account page.
        createAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myInt = new Intent(MainActivity.this, CreateAccount.class);
                startActivity(myInt);
            }
        });


    }
}