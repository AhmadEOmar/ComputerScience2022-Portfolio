package com.assignment.inventoryapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class ItemDBHelper  extends SQLiteOpenHelper {

    // tells our program to make a SQLite database called Inventory.db
    public ItemDBHelper(Context context) {
        super(context, "Inventory.db", null, 1);
    }

    // creates the database with our itemID being the primary key and everything is TEXT
    @Override
    public void onCreate(SQLiteDatabase myDB) {
        myDB.execSQL("create table Inventory(itemId TEXT primary key, itemName TEXT, itemAmount TEXT)");
    }

    // if upgraded it will drop the table if it exists
    @Override
    public void onUpgrade(SQLiteDatabase myDB, int i, int ii) {
        myDB.execSQL("drop Table if exists Inventory");
    }

    // our boolean class for inserting data into our database which will take
    // itemId, itemName, and itemAmount as strings into the database
    public Boolean insertInventoryData(String itemId, String itemName, String itemAmount)
    {
        // lets us to write into the database and update the content for each field
        SQLiteDatabase myDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("itemId", itemId);
        contentValues.put("itemName", itemName);
        contentValues.put("itemAmount", itemAmount);
        long result = myDB.insert("Inventory", null, contentValues);

        if(result == -1)
        {
            return false;
        }
        else
        {
            return true;
        }
    }


    // our boolean class for updating data into our database which will take
    // itemId and then use that to update the itemName and itemAmount
    public Boolean updateInventoryData(String itemId, String itemName, String itemAmount)
    {
        // lets us to write into the database and update the content for each field
        SQLiteDatabase myDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("itemName", itemName);
        contentValues.put("itemAmount", itemAmount);
        // checks for the itemId to be able to update the itemName and itemAmount
        Cursor cursor = myDB.rawQuery("Select * from Inventory where itemId = ?", new String[] {itemId});
        if(cursor.getCount()>0) {
            long result = myDB.update("Inventory", contentValues, "itemId=?", new String[]{itemId});

            if (result == -1) {
                return false;
            } else {
                return true;
            }
        }
        else
        {
            return false;
        }
    }

    // our boolean class for deleting data from our database which will take
    // itemId and then delete the data from the database table.
    public Boolean deleteInventoryData(String itemId)
    {
        // lets us write into the database which we will be using the itemId to delete it from there
        SQLiteDatabase myDB = this.getWritableDatabase();
        Cursor cursor = myDB.rawQuery("Select * from Inventory where itemId = ?", new String[] {itemId});
        if(cursor.getCount()>0) {
            long result = myDB.delete("Inventory", "itemId=?", new String[]{itemId});

            if (result == -1) {
                return false;
            } else {
                return true;
            }
        }
        else
        {
            return false;
        }
    }

    // Our Cursor function which will get the data from the database which will allow us to view
    // the data in our inventory page
    public Cursor getData()
    {
        SQLiteDatabase myDB = this.getWritableDatabase();
        Cursor cursor = myDB.rawQuery("Select * from Inventory", null);
        return cursor;
    }
}
