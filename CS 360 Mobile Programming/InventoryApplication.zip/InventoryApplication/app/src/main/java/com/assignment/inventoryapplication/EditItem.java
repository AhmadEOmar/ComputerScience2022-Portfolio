package com.assignment.inventoryapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class EditItem extends AppCompatActivity {

    // Down below here is where we call our items so that we can get
    // them connected to the xml file and be able to use them
    EditText itemId, itemDescriptionUpdate, itemAmountUpdate;
    Button backToInventory, editItem;

    // Calling our ItemDBHelper class which has the logic for our edit process
    ItemDBHelper myDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_item);

        // connecting our items to our xml files so that we can use them
        itemId = (EditText) findViewById(R.id.itemIdInput);
        itemDescriptionUpdate = (EditText) findViewById(R.id.editItemDescription);
        itemAmountUpdate = (EditText) findViewById(R.id.enterEditItemAmount);

        // connecting our items to our xml files so that we can use them
        backToInventory = (Button) findViewById(R.id.cancelEditButton);
        editItem = (Button) findViewById(R.id.editItemButton);

        // Calling in our ItemDBHelper class which will
        // allow us to use the functions in that class
        // to edit items
        myDB = new ItemDBHelper(this);

        // our edit page will get the strings from the user
        // that they input to be able to change the data
        // we check the data by the item id so that is unable to be changed
        editItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // gets the strings from the edit text fields
                String itemIdInput = itemId.getText().toString();
                String itemDesUpdateString = itemDescriptionUpdate.getText().toString();
                String itemAmountUpdateString = itemAmountUpdate.getText().toString();

                // calls our update function which will search by item id to change the
                // item description and item amount
                Boolean updateData = myDB.updateInventoryData(itemIdInput, itemDesUpdateString, itemAmountUpdateString);
                if(updateData == true)
                {
                    // if the id matches it will tell the user the database has been updated
                    // and take them back to the inventory page where they will see the items are
                    // now updated
                    Toast.makeText(EditItem.this, "Item Updated", Toast.LENGTH_SHORT).show();
                    Intent myInt = new Intent(EditItem.this, InventoryPage.class);
                    startActivity(myInt);
                }
                else
                {
                    // if the item id does not match it will let the user konw that that item was
                    // unable to update
                    Toast.makeText(EditItem.this, "Item Was Not Able To Update", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Our cancel button that will take the user back to the inventory page if they didn't
        // mean to get into the edit page
        backToInventory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myInt = new Intent(EditItem.this, InventoryPage.class);
                startActivity(myInt);
            }
        });


    }
}