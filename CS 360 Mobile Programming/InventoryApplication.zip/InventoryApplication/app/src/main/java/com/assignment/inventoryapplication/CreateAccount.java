package com.assignment.inventoryapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class CreateAccount extends AppCompatActivity {

    // Down below here is where we call our items so that we can get
    // them connected to the xml file and be able to use them
    EditText username, password, retypPassword;
    Button backToLogin, createAccount;
    TextView backToLoginText;

    // Calling our DBHelper class which has the logic for our login creation
    DBHelper myDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);

        // connecting our items to our xml files so that we can use them
        username = (EditText) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);
        retypPassword = (EditText) findViewById(R.id.retypePassword);

        // connecting our items to our xml files so that we can use them
        backToLoginText = (TextView) findViewById(R.id.backToSignIn);

        // connecting our items to our xml files so that we can use them
        createAccount = (Button) findViewById(R.id.createAccountButton);
        backToLogin = (Button) findViewById(R.id.backtoSignInButton);

        // Calling in our DBHelper class which will allow us to use the functions in that class
        myDB = new DBHelper(this);

        // our create account button will get the information from the edit text fields that we have
        createAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = username.getText().toString();
                String pass = password.getText().toString();
                String retypePass = retypPassword.getText().toString();

                // we are checking to ensure that the username and password fields are filled in
                // if not the user will get a prompt telling them to do that
                if(user.equals("") || pass.equals(""))
                {
                    Toast.makeText(CreateAccount.this, "Fill all the fields.", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    // if our password equals our re-type password edit text we will then start our
                    // account creation
                    if(pass.equals(retypePass))
                    {
                        // Here we check if the username is unique
                        Boolean validUsername = myDB.checkUsername(user);
                        if(validUsername == false)
                        {
                            // if the username is unique then we can insert the data of the username
                            // and password into our database
                           Boolean regResult = myDB.insertData(user, pass);
                           if(regResult == true)
                           {
                               // Toast to let the user know they have sucessfully finished the
                               // account creation process
                               // and it takes them back to the login screen
                               Toast.makeText(CreateAccount.this, "Registration Successfully Completed", Toast.LENGTH_SHORT).show();
                               Intent myInt = new Intent(CreateAccount.this, MainActivity.class);
                               startActivity(myInt);
                           }
                           else
                           {
                               // if it failed to register then inform the user of the failure
                               Toast.makeText(CreateAccount.this, "Registration Failed", Toast.LENGTH_SHORT).show();
                           }
                        }
                        else
                        {
                            // if the username already exist then let the user know that
                            // account name already is there and to go back and sign in
                            Toast.makeText(CreateAccount.this, "User Already Exisits. \n Please sign in.", Toast.LENGTH_SHORT).show();
                        }
                    }
                    else
                    {
                        // if the password and re-type password don't match let the user know that
                        Toast.makeText(CreateAccount.this, "Passwords Don't Match", Toast.LENGTH_LONG).show();
                    }
                }
            }
        });

        // back to login button that takes the user back to the login screen if they
        // accidentally clicked on create new user in the login page
        backToLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myInt = new Intent(CreateAccount.this, MainActivity.class);
                startActivity(myInt);
            }
        });

        // back to login text that takes the user back to the login screen if they
        // accidentally clicked on create new user in the login page
        backToLoginText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myInt = new Intent(CreateAccount.this, MainActivity.class);
                startActivity(myInt);
            }
        });
    }
}