package com.assignment.inventoryapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class InventoryPage extends AppCompatActivity {

    // Code we will be comparing to ensure that we have proper permission to send SMS notifcations
    private int SEND_SMS_PERMISSION_CODE = 1;

    // Down below is where we call all our Buttons,
    // our recyclerView to show case the data from the database,
    // our array where our data comes from,
    // our ItemDBHelper
    // and our DataLayout adapter which is how the data will be formatted in the inventory page.
    RecyclerView recyclerView;

    ArrayList<String>  itemId, itemName, itemAmount;

    Button logout, addItem, smsPermission, deleteItem;
    ItemDBHelper myDB;

    DataLayout adapter;

    // Our onCreate function
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_page);

        // Connecting our information to our xml inventory page layout
        smsPermission = (Button) findViewById(R.id.requestPermissionButton);
        addItem = (Button) findViewById(R.id.addItemButton);
        logout = (Button) findViewById(R.id.signOutButton);
        deleteItem = (Button) findViewById(R.id.deleteButton);

        // Connecting our ItemDBHelper with a new one
        myDB = new ItemDBHelper(this);

        // Our item array lists on how our data will be shown and pulled from
        itemName = new ArrayList<>();
        itemAmount = new ArrayList<>();
        itemId = new ArrayList<>();

        // our recycler view on where the data should go
        recyclerView = findViewById(R.id.recyclerView);

        // our adapter from datalayout on how our data should look like
        adapter = new DataLayout(this, itemId, itemName, itemAmount);

        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // call our display function to show the data from the database is there is any
        displayData();

        // Our logout button will take the user back to the login page when they click it
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myInt = new Intent(InventoryPage.this, MainActivity.class);
                startActivity(myInt);
            }
        });


        // Our sms permission button which will check if we have already given permission and if not it will call the requestSMSPermission function
        smsPermission.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ContextCompat.checkSelfPermission(InventoryPage.this,
                        android.Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED)
                {
                    Toast.makeText(InventoryPage.this,  "You have already granted this permission!", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    requestSMSPermission();
                }
            }
        });

        // Our add item button when clicked will take the user to the add item page
        addItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myInt = new Intent(InventoryPage.this, AddItem.class);
                startActivity(myInt);
            }
        });

        // Our delete button which will take the user to the delete button screen
        deleteItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myInt = new Intent(InventoryPage.this, DeleteItem.class);
                startActivity(myInt);
            }
        });


    }

    // Our display data function which will go through the data and display it if there is any data
    // if no data is found a message will popup asking the user to add item to the inventory database
    // if there is data it will grab it by where the data is located in the database
    private void displayData() {
        Cursor cursor = myDB.getData();
        if(cursor.getCount() == 0)
        {
            Toast.makeText(InventoryPage.this, "No Entry Exists Please Add Item To Inventory", Toast.LENGTH_SHORT).show();
            return;
        }
        else
        {
            while(cursor.moveToNext())
            {
                itemId.add((cursor.getString(0)));
                itemName.add(cursor.getString(1));
                itemAmount.add(cursor.getString(2));
            }
        }
    }

    // Our request sms permission function which will prompt the user when they click on the sms button in the inventory page
    // It will create a dialog asking for the permission and if they deny it it will show the reasoning on why we need the permission.
    private void requestSMSPermission()
    {
        if(ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SEND_SMS))
        {
            new AlertDialog.Builder(this)
                    .setTitle("SMS Permission Needed")
                    .setMessage("This permission is needed so that we can send you a notification when an item in your inventory hits 0. \n\n" +
                            "You can turn this off but the notification feature won't work. You can also allow the permission in the app settings.")
                    .setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            ActivityCompat.requestPermissions(InventoryPage.this, new String[] {Manifest.permission.SEND_SMS}, SEND_SMS_PERMISSION_CODE);
                        }
                    })
                    .setNegativeButton("Deny", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    })
                    .create().show();

        }
        else
        {
            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.SEND_SMS}, SEND_SMS_PERMISSION_CODE);
        }
    }


    // If we already have permission either confirmed or denied this function will be called that informs the user that they have
    // allowed permission or denied permission.
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if(requestCode == SEND_SMS_PERMISSION_CODE)
        {
            if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
            {
                Toast.makeText(this, "Permission Granted", Toast.LENGTH_SHORT).show();
            }
            else
            {
                Toast.makeText(this, "Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}